setwd("C:\\Users\\IT24103690\\Desktop\\IT24103690")

# 2. Import the dataset
data <- read.csv("Exercise - LaptopsWeights.csv")

# View first few rows (optional)
head(data)

# 3. Calculate population mean and standard deviation
pop_mean <- mean(data$Weight)
pop_sd <- sd(data$Weight)

cat("Population Mean:", pop_mean, "\n")
cat("Population SD:", pop_sd, "\n")

# 4. Draw 25 random samples of size 6 (with replacement)
set.seed(123)  # for reproducibility

sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample_i <- sample(data$Weight, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
}

# Show all sample means and SDs
cat("\nSample Means:\n")
print(sample_means)

cat("\nSample SDs:\n")
print(sample_sds)

# 5. Mean and SD of sample means
mean_sample_means <- mean(sample_means)
sd_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", mean_sample_means, "\n")
cat("SD of Sample Means:", sd_sample_means, "\n")
