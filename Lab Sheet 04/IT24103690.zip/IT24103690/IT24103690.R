setwd("C:/Users/IT24103690/Desktop/IT24103690")

#Importing data
branch_data<-read.table("Exercise.txt",header = TRUE, sep = " ")

head(data)

class(branch_data$variable_name)

str(branch_data)

#SCALE AND VARIABLE TYPE

## Create a data frame with the variables, data types, and measurement scales
data_table <- data.frame(
  Variable = c("Branch", "Sales_X1", "Advertising_X2", "Years_X3"),
  Data_Type = c("Factor", "Numeric", "Numeric", "Numeric"),
  Measurement_Scale = c("Nominal", "Ratio", "Ratio", "Ratio")
)

# Display the table
print(data_table)

boxplot(branch_data$Sales_X1, main = "Boxplot for Sales_X1", 
        ylab = "Sales", col = "lightblue", border = "darkblue")

# Calculate the five-number summary for the Advertising_X2 variable
summary(branch_data$Advertising_X2)

# Calculate the IQR (Interquartile Range)
iqr_advertising <- IQR(branch_data$Advertising_X2)

# Display the IQR
print(paste("IQR for Advertising_X2: ", iqr_advertising))

# Define a function to detect outliers
find_outliers <- function(x) {
  # Calculate Q1, Q3, and IQR
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  # Define the lower and upper bounds for outliers
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  # Find the outliers
  outliers <- x[x < lower_bound | x > upper_bound]
  
  return(outliers)
}

# Check for outliers in the Years_X3 variable
outliers_years <- find_outliers(branch_data$Years_X3)

# Print the outliers for Years_X3
print("Outliers in Years_X3:")
print(outliers_years)
